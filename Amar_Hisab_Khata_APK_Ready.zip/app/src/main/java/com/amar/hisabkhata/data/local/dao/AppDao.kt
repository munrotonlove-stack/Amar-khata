package com.amar.hisabkhata.data.local.dao

import androidx.room.*
import com.amar.hisabkhata.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // ---------- Students ----------
    @Query("SELECT * FROM students ORDER BY createdAt DESC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students")
    suspend fun getStudentsOnce(): List<StudentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity)

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Query("DELETE FROM students WHERE id = :studentId")
    suspend fun deleteStudent(studentId: String)

    @Query("DELETE FROM students")
    suspend fun deleteAllStudents()

    // ---------- Monthly Fees ----------
    @Query("SELECT * FROM monthly_fees WHERE monthYear = :monthYear")
    fun getFeesForMonth(monthYear: String): Flow<List<MonthlyFeeEntity>>

    @Query("SELECT * FROM monthly_fees WHERE monthYear = :monthYear")
    suspend fun getFeesForMonthOnce(monthYear: String): List<MonthlyFeeEntity>

    @Query("SELECT * FROM monthly_fees")
    suspend fun getAllFeesOnce(): List<MonthlyFeeEntity>

    @Query("SELECT * FROM monthly_fees WHERE id = :id")
    suspend fun getFee(id: String): MonthlyFeeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFees(fees: List<MonthlyFeeEntity>)

    @Update
    suspend fun updateFee(fee: MonthlyFeeEntity)

    @Query("DELETE FROM monthly_fees WHERE studentId = :studentId")
    suspend fun deleteFeesForStudent(studentId: String)

    @Query("DELETE FROM monthly_fees")
    suspend fun deleteAllFees()

    // ---------- Payments ----------
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: StudentPaymentEntity)

    @Query("SELECT * FROM student_payments WHERE id = :id")
    suspend fun getPayment(id: String): StudentPaymentEntity?

    @Query("SELECT * FROM student_payments")
    suspend fun getAllPaymentsOnce(): List<StudentPaymentEntity>

    @Query("DELETE FROM student_payments WHERE id = :id")
    suspend fun deletePayment(id: String)

    @Query("DELETE FROM student_payments WHERE studentId = :studentId")
    suspend fun deletePaymentsForStudent(studentId: String)

    @Query("DELETE FROM student_payments")
    suspend fun deleteAllPayments()

    // ---------- Incomes ----------
    @Query("SELECT * FROM incomes WHERE monthYear = :monthYear ORDER BY date DESC")
    fun getIncomesForMonth(monthYear: String): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM incomes ORDER BY date DESC")
    fun getAllIncomes(): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM incomes")
    suspend fun getAllIncomesOnce(): List<IncomeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncome(income: IncomeEntity)

    @Delete
    suspend fun deleteIncome(income: IncomeEntity)

    @Query("DELETE FROM incomes WHERE studentId = :studentId")
    suspend fun deleteIncomesForStudent(studentId: String)

    @Query("DELETE FROM incomes")
    suspend fun deleteAllIncomes()

    // ---------- Expenses ----------
    @Query("SELECT * FROM expenses WHERE monthYear = :monthYear ORDER BY date DESC")
    fun getExpensesForMonth(monthYear: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses")
    suspend fun getAllExpensesOnce(): List<ExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses")
    suspend fun deleteAllExpenses()

    // ---------- Debts & Receivables ----------
    @Query("SELECT * FROM debts ORDER BY date DESC")
    fun getAllDebts(): Flow<List<DebtEntity>>

    @Query("SELECT * FROM debts")
    suspend fun getAllDebtsOnce(): List<DebtEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: DebtEntity)

    @Update
    suspend fun updateDebt(debt: DebtEntity)

    @Delete
    suspend fun deleteDebt(debt: DebtEntity)

    @Query("DELETE FROM debts")
    suspend fun deleteAllDebts()

    // ---------- Debt settlements ----------
    @Query("SELECT * FROM debt_settlements ORDER BY date DESC")
    fun getAllSettlements(): Flow<List<DebtSettlementEntity>>

    @Query("SELECT * FROM debt_settlements")
    suspend fun getAllSettlementsOnce(): List<DebtSettlementEntity>

    @Query("SELECT * FROM debt_settlements WHERE id = :id")
    suspend fun getSettlement(id: String): DebtSettlementEntity?

    @Query("SELECT * FROM debts WHERE id = :id")
    suspend fun getDebt(id: String): DebtEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: DebtSettlementEntity)

    @Query("DELETE FROM debt_settlements WHERE id = :id")
    suspend fun deleteSettlement(id: String)

    @Query("DELETE FROM debt_settlements WHERE debtId = :debtId")
    suspend fun deleteSettlementsForDebt(debtId: String)

    @Query("DELETE FROM debt_settlements")
    suspend fun deleteAllSettlements()

    // ---------- Audit logs ----------
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs")
    suspend fun getAllLogsOnce(): List<AuditLogEntity>

    @Query("DELETE FROM audit_logs")
    suspend fun deleteAllLogs()
}
