@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.data.local.entity.MonthlyFeeEntity
import com.amar.hisabkhata.data.local.entity.StudentEntity
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt

@Composable
fun StudentsScreen(vm: MainViewModel) {
    val month by vm.selectedMonth.collectAsState()
    val students by vm.students.collectAsState()
    val fees by vm.monthFees.collectAsState()

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<StudentEntity?>(null) }
    var payTarget by remember { mutableStateOf<StudentEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<StudentEntity?>(null) }

    val feeByStudent = fees.associateBy { it.studentId }

    val visible = students.filter { s ->
        val matchesQuery = query.isBlank() ||
            s.name.contains(query, ignoreCase = true) ||
            s.phoneNumber.contains(query)
        val fee = feeByStudent[s.id]
        val matchesFilter = when (filter) {
            "archived" -> !s.isActive
            "due" -> s.isActive && fee != null && fee.dueAmount > 0.0
            "paid" -> s.isActive && fee != null && fee.status == "paid"
            else -> s.isActive
        }
        matchesQuery && matchesFilter
    }

    val totalDue = fees.sumOf { it.dueAmount }
    val totalCollected = fees.sumOf { it.paidAmount }

    ScreenWithFab(onFabClick = { showAdd = true }) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { MonthSwitcher(month, vm::setMonth) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryCard("আদায় হয়েছে", Fmt.money(totalCollected), SuccessGreen, Modifier.weight(1f))
                    SummaryCard("বকেয়া", Fmt.money(totalDue), ErrorRed, Modifier.weight(1f))
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("নাম বা ফোন নম্বর দিয়ে খুঁজুন") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true
                )
            }
            item {
                ChipRow(
                    options = listOf("all" to "চলতি", "due" to "বকেয়া", "paid" to "পরিশোধিত", "archived" to "আর্কাইভ"),
                    selected = filter,
                    onSelect = { filter = it }
                )
            }

            if (visible.isEmpty()) {
                item {
                    EmptyState(
                        if (students.isEmpty()) "কোনো শিক্ষার্থী নেই।\nনিচের + বাটনে চাপ দিয়ে যোগ করুন।"
                        else "কোনো ফলাফল পাওয়া যায়নি"
                    )
                }
            }

            items(visible, key = { it.id }) { student ->
                StudentCard(
                    student = student,
                    fee = feeByStudent[student.id],
                    onPay = { payTarget = student },
                    onToggleArchive = { vm.saveStudent(student.copy(isActive = !student.isActive), isNew = false) },
                    onEdit = { editing = student },
                    onDelete = { deleteTarget = student }
                )
            }
        }
    }

    if (showAdd) {
        StudentDialog(
            initial = null,
            onDismiss = { showAdd = false },
            onSave = {
                vm.saveStudent(it, isNew = true)
                showAdd = false
            }
        )
    }

    editing?.let { current ->
        StudentDialog(
            initial = current,
            onDismiss = { editing = null },
            onSave = {
                vm.saveStudent(it, isNew = false)
                editing = null
            }
        )
    }

    payTarget?.let { student ->
        val fee = feeByStudent[student.id]
        if (fee != null) {
            PayFeeDialog(
                student = student,
                fee = fee,
                onDismiss = { payTarget = null },
                onPay = { amount, date ->
                    vm.payFee(student, fee, amount, date)
                    payTarget = null
                }
            )
        }
    }

    deleteTarget?.let { student ->
        DeleteConfirmDialog(
            message = "\"${student.name}\" কে মুছলে তার সব ফি, পেমেন্ট ও সংশ্লিষ্ট আয়ের হিসাবও মুছে যাবে। এটি আর ফেরানো যাবে না।",
            onConfirm = {
                vm.deleteStudent(student)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun StudentCard(
    student: StudentEntity,
    fee: MonthlyFeeEntity?,
    onPay: () -> Unit,
    onToggleArchive: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(PrimaryDarkGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        student.name.trim().take(1),
                        color = Gold,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(student.name, fontWeight = FontWeight.SemiBold, color = MainText)
                    Text(
                        if (student.phoneNumber.isBlank()) "ফোন নেই" else Fmt.bn(student.phoneNumber),
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        Fmt.money(student.monthlyFee),
                        fontWeight = FontWeight.Bold,
                        color = PrimaryDarkGreen
                    )
                    Text("মাসিক ফি", style = MaterialTheme.typography.labelSmall, color = SecondaryText)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (fee != null) {
                    StatusBadge(fee.status)
                    Spacer(Modifier.width(8.dp))
                    if (fee.dueAmount > 0.0) {
                        Text(
                            "বকেয়া ${Fmt.money(fee.dueAmount)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = ErrorRed
                        )
                    }
                } else {
                    Text(
                        "এই মাসে ফি প্রযোজ্য নয়",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
                Spacer(Modifier.weight(1f))
                if (student.isActive && fee != null && fee.dueAmount > 0.0) {
                    Button(onClick = onPay, contentPadding = PaddingValues(horizontal = 14.dp)) {
                        Text("ফি আদায়")
                    }
                }
                TextButton(onClick = onToggleArchive) {
                    Text(if (student.isActive) "আর্কাইভ" else "সক্রিয় করুন", color = SecondaryText)
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Filled.Edit, contentDescription = "সম্পাদনা", tint = SecondaryText)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = ErrorRed)
                }
            }
        }
    }
}

@Composable
private fun StudentDialog(
    initial: StudentEntity?,
    onDismiss: () -> Unit,
    onSave: (StudentEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phoneNumber ?: "") }
    var fee by remember { mutableStateOf(initial?.monthlyFee?.let { Fmt.plain(it) } ?: "") }
    var joining by remember { mutableStateOf(initial?.joiningDate ?: Fmt.today()) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    val feeValue = Fmt.parseAmount(fee)

    FormDialog(
        title = if (initial == null) "নতুন শিক্ষার্থী" else "শিক্ষার্থীর তথ্য সম্পাদনা",
        onDismiss = onDismiss,
        confirmEnabled = name.isNotBlank() && feeValue != null && feeValue > 0.0 && Fmt.isValidDate(joining),
        onConfirm = {
            val base = initial ?: StudentEntity(
                id = Fmt.newId(),
                name = "",
                phoneNumber = "",
                monthlyFee = 0.0,
                joiningDate = joining
            )
            onSave(
                base.copy(
                    name = name.trim(),
                    phoneNumber = phone.trim(),
                    monthlyFee = feeValue ?: 0.0,
                    joiningDate = joining,
                    notes = notes.ifBlank { null }
                )
            )
        }
    ) {
        AppTextField(name, { name = it }, "শিক্ষার্থীর নাম")
        AppTextField(phone, { phone = it }, "ফোন নম্বর (ঐচ্ছিক)", keyboardType = KeyboardType.Phone)
        AppTextField(fee, { fee = it }, "মাসিক ফি (৳)", keyboardType = KeyboardType.Decimal)
        DateField(joining, { joining = it }, "ভর্তির তারিখ (YYYY-MM-DD)")
        AppTextField(notes, { notes = it }, "নোট (ঐচ্ছিক)", singleLine = false)
    }
}

@Composable
private fun PayFeeDialog(
    student: StudentEntity,
    fee: MonthlyFeeEntity,
    onDismiss: () -> Unit,
    onPay: (Double, String) -> Unit
) {
    var amount by remember { mutableStateOf(Fmt.plain(fee.dueAmount)) }
    var date by remember { mutableStateOf(Fmt.today()) }
    val value = Fmt.parseAmount(amount)

    FormDialog(
        title = "ফি আদায়: ${student.name}",
        confirmText = "আদায় করুন",
        onDismiss = onDismiss,
        confirmEnabled = value != null && value > 0.0 && Fmt.isValidDate(date),
        onConfirm = { onPay(value ?: 0.0, date) }
    ) {
        Text(
            "${Fmt.monthLabel(fee.monthYear)} — মোট ${Fmt.money(fee.amount)}, বকেয়া ${Fmt.money(fee.dueAmount)}",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryText
        )
        AppTextField(amount, { amount = it }, "আদায়ের পরিমাণ (৳)", keyboardType = KeyboardType.Decimal)
        DateField(date, { date = it })
        if (value != null && value > fee.dueAmount) {
            Text(
                "বকেয়ার চেয়ে বেশি দিলে শুধু বকেয়া পরিমাণই আদায় হবে।",
                style = MaterialTheme.typography.bodySmall,
                color = WarningGold
            )
        }
    }
}
