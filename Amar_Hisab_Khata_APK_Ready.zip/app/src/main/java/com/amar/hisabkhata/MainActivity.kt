package com.amar.hisabkhata

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.amar.hisabkhata.ui.navigation.MainAppNavigation
import com.amar.hisabkhata.ui.screens.PinLockScreen
import com.amar.hisabkhata.ui.theme.AmarHisabKhataTheme
import com.amar.hisabkhata.util.PinStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AmarHisabKhataTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val context = LocalContext.current
                    var unlocked by remember { mutableStateOf(!PinStore.hasPin(context)) }
                    if (unlocked) {
                        MainAppNavigation()
                    } else {
                        PinLockScreen(onUnlocked = { unlocked = true })
                    }
                }
            }
        }
    }
}
