@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt
import com.amar.hisabkhata.util.Labels

@Composable
fun ReportsScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = CardBackground) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("মাসিক") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("বার্ষিক") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("অডিট") })
        }
        when (tab) {
            0 -> MonthlyReport(vm)
            1 -> AnnualReport(vm)
            else -> AuditTrail(vm)
        }
    }
}

@Composable
private fun MonthlyReport(vm: MainViewModel) {
    val month by vm.selectedMonth.collectAsState()
    val incomes by vm.incomes.collectAsState()
    val expenses by vm.expenses.collectAsState()

    val monthIncomes = incomes.filter { it.monthYear == month && it.isReceived }
    val monthExpenses = expenses.filter { it.monthYear == month }
    val totalIncome = monthIncomes.sumOf { it.amount }
    val totalExpense = monthExpenses.sumOf { it.amount }
    val balance = totalIncome - totalExpense

    val incomeBreakdown = monthIncomes.groupBy { it.category }
        .map { (key, list) -> Labels.income(key) to list.sumOf { it.amount } }
        .sortedByDescending { it.second }
    val expenseBreakdown = monthExpenses.groupBy { it.category }
        .map { (key, list) -> Labels.expense(key) to list.sumOf { it.amount } }
        .sortedByDescending { it.second }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { MonthSwitcher(month, vm::setMonth) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("মোট আয়", Fmt.money(totalIncome), SuccessGreen, Modifier.weight(1f))
                SummaryCard("মোট ব্যয়", Fmt.money(totalExpense), ErrorRed, Modifier.weight(1f))
            }
        }
        item {
            SummaryCard(
                "মাসের উদ্বৃত্ত",
                Fmt.money(balance),
                if (balance >= 0) PrimaryDarkGreen else ErrorRed,
                Modifier.fillMaxWidth()
            )
        }
        item { BreakdownCard("আয়ের খাতওয়ারি হিসাব", incomeBreakdown, totalIncome, SuccessGreen) }
        item { BreakdownCard("ব্যয়ের খাতওয়ারি হিসাব", expenseBreakdown, totalExpense, ErrorRed) }
    }
}

@Composable
private fun BreakdownCard(title: String, rows: List<Pair<String, Double>>, total: Double, color: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = CardBackground)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle(title)
            if (rows.isEmpty()) {
                Text("কোনো তথ্য নেই", color = SecondaryText)
            }
            rows.forEach { (label, value) ->
                Column {
                    Row {
                        Text(label, Modifier.weight(1f), color = MainText)
                        Text(Fmt.money(value), fontWeight = FontWeight.SemiBold, color = color)
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { if (total > 0.0) (value / total).toFloat() else 0f },
                        modifier = Modifier.fillMaxWidth(),
                        color = color,
                        trackColor = LightGold
                    )
                }
            }
        }
    }
}

@Composable
private fun AnnualReport(vm: MainViewModel) {
    val incomes by vm.incomes.collectAsState()
    val expenses by vm.expenses.collectAsState()
    var year by remember { mutableIntStateOf(Fmt.currentMonth().take(4).toInt()) }

    val months = (1..12).map { String.format(java.util.Locale.US, "%04d-%02d", year, it) }
    val monthlyIncome = months.map { m -> incomes.filter { it.monthYear == m && it.isReceived }.sumOf { it.amount } }
    val monthlyExpense = months.map { m -> expenses.filter { it.monthYear == m }.sumOf { it.amount } }
    val yearIncome = monthlyIncome.sum()
    val yearExpense = monthlyExpense.sum()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { year -= 1 }) {
                    Icon(Icons.Filled.ChevronLeft, contentDescription = "আগের বছর")
                }
                Text(
                    Fmt.bn(year.toString()),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryDarkGreen
                )
                IconButton(onClick = { year += 1 }) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "পরের বছর")
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("বার্ষিক আয়", Fmt.money(yearIncome), SuccessGreen, Modifier.weight(1f))
                SummaryCard("বার্ষিক ব্যয়", Fmt.money(yearExpense), ErrorRed, Modifier.weight(1f))
            }
        }
        item {
            SummaryCard(
                "বছরের উদ্বৃত্ত",
                Fmt.money(yearIncome - yearExpense),
                if (yearIncome - yearExpense >= 0) PrimaryDarkGreen else ErrorRed,
                Modifier.fillMaxWidth()
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("মাসওয়ারি আয় ও ব্যয়")
                    Spacer(Modifier.height(12.dp))
                    MonthlyBarChart(months, monthlyIncome, monthlyExpense)
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("মাসওয়ারি বিবরণ")
                    months.forEachIndexed { index, m ->
                        val net = monthlyIncome[index] - monthlyExpense[index]
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Fmt.monthName(index + 1), Modifier.weight(1.2f), color = MainText)
                            Text(
                                Fmt.money(monthlyIncome[index]),
                                Modifier.weight(1f),
                                color = SuccessGreen,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                Fmt.money(monthlyExpense[index]),
                                Modifier.weight(1f),
                                color = ErrorRed,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                Fmt.money(net),
                                Modifier.weight(1f),
                                color = if (net >= 0) PrimaryDarkGreen else ErrorRed,
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditTrail(vm: MainViewModel) {
    val logs by vm.logs.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (logs.isEmpty()) {
            item { EmptyState("এখনো কোনো কার্যক্রম নেই") }
        }
        items(logs, key = { it.id }) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(log.action, fontWeight = FontWeight.SemiBold, color = PrimaryDarkGreen)
                    Text(log.details, style = MaterialTheme.typography.bodyMedium, color = MainText)
                    Text(
                        Fmt.dateTime(log.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = SecondaryText
                    )
                }
            }
        }
    }
}
