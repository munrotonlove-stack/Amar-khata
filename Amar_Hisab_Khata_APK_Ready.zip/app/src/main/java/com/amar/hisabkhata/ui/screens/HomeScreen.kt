@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt

@Composable
fun HomeScreen(vm: MainViewModel, onNavigate: (String) -> Unit) {
    val month by vm.selectedMonth.collectAsState()
    val incomes by vm.incomes.collectAsState()
    val expenses by vm.expenses.collectAsState()
    val debts by vm.debts.collectAsState()

    val monthIncome = incomes.filter { it.monthYear == month && it.isReceived }.sumOf { it.amount }
    val monthExpense = expenses.filter { it.monthYear == month }.sumOf { it.amount }
    val receivable = debts.filter { it.type == "others_owe_me" }.sumOf { it.remainingAmount }
    val payable = debts.filter { it.type == "owe_others" }.sumOf { it.remainingAmount }
    val totalBalance = incomes.filter { it.isReceived }.sumOf { it.amount } - expenses.sumOf { it.amount }

    // শেষ ৬ মাসের চার্ট ডেটা
    val chartMonths = (5 downTo 0).map { Fmt.shiftMonth(month, -it) }
    val chartIncome = chartMonths.map { m ->
        incomes.filter { it.monthYear == m && it.isReceived }.sumOf { it.amount }
    }
    val chartExpense = chartMonths.map { m ->
        expenses.filter { it.monthYear == m }.sumOf { it.amount }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { MonthSwitcher(month, vm::setMonth) }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = PrimaryDarkGreen)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("মোট জমা (সব সময়ের ব্যালেন্স)", color = LightGold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        Fmt.money(totalBalance),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Gold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${Fmt.monthLabel(month)}: " + Fmt.money(monthIncome - monthExpense),
                        color = androidx.compose.ui.graphics.Color.White
                    )
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("এ মাসের আয়", Fmt.money(monthIncome), SuccessGreen, Modifier.weight(1f))
                SummaryCard("এ মাসের ব্যয়", Fmt.money(monthExpense), ErrorRed, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("মোট পাওনা", Fmt.money(receivable), Purple, Modifier.weight(1f))
                SummaryCard("মোট দেনা", Fmt.money(payable), WarningGold, Modifier.weight(1f))
            }
        }

        item { SectionTitle("দ্রুত কাজ") }
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { onNavigate("students") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("ফি আদায়") }
                Button(
                    onClick = { onNavigate("income") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("আয় যোগ") }
                Button(
                    onClick = { onNavigate("expense") },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("ব্যয় যোগ") }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("শেষ ৬ মাসের আয় ও ব্যয়")
                    Spacer(Modifier.height(12.dp))
                    MonthlyBarChart(chartMonths, chartIncome, chartExpense)
                }
            }
        }
    }
}
