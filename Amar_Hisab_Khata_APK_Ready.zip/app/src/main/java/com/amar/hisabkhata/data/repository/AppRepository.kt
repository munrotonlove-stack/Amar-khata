package com.amar.hisabkhata.data.repository

import androidx.room.withTransaction
import com.amar.hisabkhata.data.local.AppDatabase
import com.amar.hisabkhata.data.local.dao.AppDao
import com.amar.hisabkhata.data.local.entity.*
import com.amar.hisabkhata.util.Fmt
import com.amar.hisabkhata.util.Labels
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class AppRepository(
    private val db: AppDatabase,
    private val dao: AppDao
) {
    val students: Flow<List<StudentEntity>> = dao.getAllStudents()
    val incomes: Flow<List<IncomeEntity>> = dao.getAllIncomes()
    val expenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    val debts: Flow<List<DebtEntity>> = dao.getAllDebts()
    val settlements: Flow<List<DebtSettlementEntity>> = dao.getAllSettlements()
    val logs: Flow<List<AuditLogEntity>> = dao.getAllLogs()

    fun feesForMonth(month: String): Flow<List<MonthlyFeeEntity>> = dao.getFeesForMonth(month)

    private suspend fun log(action: String, details: String) {
        dao.insertLog(
            AuditLogEntity(
                id = Fmt.newId(),
                action = action,
                details = details,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // ------------------------------------------------------------------
    // Students & fees
    // ------------------------------------------------------------------
    suspend fun saveStudent(student: StudentEntity, isNew: Boolean) {
        if (isNew) dao.insertStudent(student) else dao.updateStudent(student)
        log(
            if (isNew) "শিক্ষার্থী যোগ" else "শিক্ষার্থী সম্পাদনা",
            "${student.name} (মাসিক ফি ${Fmt.money(student.monthlyFee)})"
        )
    }

    /** শিক্ষার্থী মুছলে তার ফি, পেমেন্ট ও সংশ্লিষ্ট আয়ও মুছে যায়। */
    suspend fun deleteStudent(student: StudentEntity) {
        db.withTransaction {
            dao.deleteIncomesForStudent(student.id)
            dao.deletePaymentsForStudent(student.id)
            dao.deleteFeesForStudent(student.id)
            dao.deleteStudent(student.id)
            log("শিক্ষার্থী মুছে ফেলা", student.name)
        }
    }

    /** নির্বাচিত মাসের জন্য যেসব সক্রিয় শিক্ষার্থীর ফি এন্ট্রি নেই, সেগুলো তৈরি করে। */
    suspend fun generateFees(month: String) {
        val existing = dao.getFeesForMonthOnce(month).map { it.studentId }.toSet()
        val newFees = dao.getStudentsOnce()
            .filter { it.isActive && it.id !in existing && it.joiningDate.take(7) <= month }
            .map {
                MonthlyFeeEntity(
                    id = "fee_${it.id}_$month",
                    studentId = it.id,
                    monthYear = month,
                    amount = it.monthlyFee,
                    paidAmount = 0.0,
                    dueAmount = it.monthlyFee,
                    status = "unpaid"
                )
            }
        if (newFees.isNotEmpty()) dao.insertFees(newFees)
    }

    suspend fun payFee(student: StudentEntity, fee: MonthlyFeeEntity, amount: Double, date: String) {
        db.withTransaction {
            val current = dao.getFee(fee.id)
            if (current != null) {
                val applied = minOf(amount, current.amount - current.paidAmount)
                if (applied > 0.0) {
                    val newPaid = current.paidAmount + applied
                    val due = current.amount - newPaid
                    dao.updateFee(
                        current.copy(
                            paidAmount = newPaid,
                            dueAmount = due,
                            status = if (due <= 0.0) "paid" else "partial",
                            lastPaymentDate = date
                        )
                    )
                    val paymentId = Fmt.newId()
                    dao.insertPayment(
                        StudentPaymentEntity(
                            id = paymentId,
                            studentId = student.id,
                            feeId = current.id,
                            amount = applied,
                            paymentDate = date,
                            monthYear = current.monthYear,
                            receiptNumber = "RC-" + System.currentTimeMillis().toString().takeLast(8)
                        )
                    )
                    dao.insertIncome(
                        IncomeEntity(
                            id = Fmt.newId(),
                            category = "student_fee",
                            title = "${student.name} - ${Fmt.monthLabel(current.monthYear)} ফি",
                            amount = applied,
                            date = date,
                            monthYear = date.take(7),
                            isReceived = true,
                            receivedDate = date,
                            studentId = student.id,
                            paymentId = paymentId
                        )
                    )
                    log("ফি আদায়", "${student.name} - ${Fmt.money(applied)} (${Fmt.monthLabel(current.monthYear)})")
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Income
    // ------------------------------------------------------------------
    suspend fun addIncome(income: IncomeEntity) {
        dao.insertIncome(income)
        log("আয় যোগ", "${Labels.income(income.category)}: ${income.title} - ${Fmt.money(income.amount)}")
    }

    suspend fun markIncomeReceived(income: IncomeEntity, date: String) {
        dao.insertIncome(income.copy(isReceived = true, receivedDate = date))
        log("আয় প্রাপ্ত", "${income.title} - ${Fmt.money(income.amount)}")
    }

    /** ছাত্র বেতনের আয় মুছলে সংশ্লিষ্ট পেমেন্ট মুছে মাসিক ফি-এর ব্যালেন্স আবার হিসাব হয়। */
    suspend fun deleteIncome(income: IncomeEntity) {
        db.withTransaction {
            val paymentId = income.paymentId
            if (paymentId != null) {
                val payment = dao.getPayment(paymentId)
                if (payment != null) {
                    val fee = dao.getFee(payment.feeId)
                    if (fee != null) {
                        val paid = (fee.paidAmount - payment.amount).coerceAtLeast(0.0)
                        val due = fee.amount - paid
                        dao.updateFee(
                            fee.copy(
                                paidAmount = paid,
                                dueAmount = due,
                                status = when {
                                    paid <= 0.0 -> "unpaid"
                                    due <= 0.0 -> "paid"
                                    else -> "partial"
                                }
                            )
                        )
                    }
                    dao.deletePayment(paymentId)
                }
            }
            dao.deleteIncome(income)
            log("আয় মুছে ফেলা", "${income.title} - ${Fmt.money(income.amount)}")
        }
    }

    // ------------------------------------------------------------------
    // Expense
    // ------------------------------------------------------------------
    suspend fun addExpense(expense: ExpenseEntity) {
        dao.insertExpense(expense)
        log("ব্যয় যোগ", "${Labels.expense(expense.category)}: ${expense.title} - ${Fmt.money(expense.amount)}")
    }

    suspend fun deleteExpense(expense: ExpenseEntity) {
        dao.deleteExpense(expense)
        log("ব্যয় মুছে ফেলা", "${expense.title} - ${Fmt.money(expense.amount)}")
    }

    // ------------------------------------------------------------------
    // Debts
    // ------------------------------------------------------------------
    suspend fun addDebt(debt: DebtEntity) {
        dao.insertDebt(debt)
        val kind = if (debt.type == "owe_others") "দেনা" else "পাওনা"
        log("$kind যোগ", "${debt.personName} - ${Fmt.money(debt.totalAmount)}")
    }

    /** নিষ্পত্তি যোগ করে; প্রতিটি নিষ্পত্তি আলাদা রেকর্ড হিসেবে ইতিহাসে থাকে। */
    suspend fun settleDebt(debt: DebtEntity, amount: Double, date: String) {
        db.withTransaction {
            val current = dao.getDebt(debt.id)
            if (current != null) {
                val applied = minOf(amount, current.totalAmount - current.settledAmount)
                if (applied > 0.0) {
                    val settled = current.settledAmount + applied
                    val remaining = current.totalAmount - settled
                    dao.updateDebt(
                        current.copy(
                            settledAmount = settled,
                            remainingAmount = remaining,
                            isFullySettled = remaining <= 0.0
                        )
                    )
                    dao.insertSettlement(
                        DebtSettlementEntity(
                            id = Fmt.newId(),
                            debtId = current.id,
                            amount = applied,
                            date = date
                        )
                    )
                    log("আংশিক নিষ্পত্তি", "${current.personName} - ${Fmt.money(applied)}")
                }
            }
        }
    }

    /** নিষ্পত্তি বাতিল করলে দেনা/পাওনার বাকি পরিমাণ আবার বেড়ে যায়। */
    suspend fun deleteSettlement(settlement: DebtSettlementEntity) {
        db.withTransaction {
            val debt = dao.getDebt(settlement.debtId)
            if (debt != null) {
                val settled = (debt.settledAmount - settlement.amount).coerceAtLeast(0.0)
                val remaining = debt.totalAmount - settled
                dao.updateDebt(
                    debt.copy(
                        settledAmount = settled,
                        remainingAmount = remaining,
                        isFullySettled = remaining <= 0.0
                    )
                )
            }
            dao.deleteSettlement(settlement.id)
            log("নিষ্পত্তি বাতিল", "${Fmt.money(settlement.amount)} (${settlement.date})")
        }
    }

    suspend fun deleteDebt(debt: DebtEntity) {
        db.withTransaction {
            dao.deleteSettlementsForDebt(debt.id)
            dao.deleteDebt(debt)
            log("দেনা/পাওনা মুছে ফেলা", debt.personName)
        }
    }

    // ------------------------------------------------------------------
    // Backup (JSON)
    // ------------------------------------------------------------------
    suspend fun exportJson(): String {
        val root = JSONObject()
        root.put("app", "amar_hisab_khata")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        root.put("students", JSONArray().also { arr ->
            dao.getStudentsOnce().forEach { s ->
                arr.put(
                    JSONObject()
                        .put("id", s.id).put("name", s.name).put("phoneNumber", s.phoneNumber)
                        .put("monthlyFee", s.monthlyFee).put("joiningDate", s.joiningDate)
                        .put("isActive", s.isActive).put("notes", s.notes ?: JSONObject.NULL)
                        .put("createdAt", s.createdAt)
                )
            }
        })
        root.put("fees", JSONArray().also { arr ->
            dao.getAllFeesOnce().forEach { f ->
                arr.put(
                    JSONObject()
                        .put("id", f.id).put("studentId", f.studentId).put("monthYear", f.monthYear)
                        .put("amount", f.amount).put("paidAmount", f.paidAmount)
                        .put("dueAmount", f.dueAmount).put("status", f.status)
                        .put("lastPaymentDate", f.lastPaymentDate ?: JSONObject.NULL)
                )
            }
        })
        root.put("payments", JSONArray().also { arr ->
            dao.getAllPaymentsOnce().forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id).put("studentId", p.studentId).put("feeId", p.feeId)
                        .put("amount", p.amount).put("paymentDate", p.paymentDate)
                        .put("monthYear", p.monthYear).put("receiptNumber", p.receiptNumber)
                        .put("notes", p.notes ?: JSONObject.NULL).put("createdAt", p.createdAt)
                )
            }
        })
        root.put("incomes", JSONArray().also { arr ->
            dao.getAllIncomesOnce().forEach { i ->
                arr.put(
                    JSONObject()
                        .put("id", i.id).put("category", i.category).put("title", i.title)
                        .put("amount", i.amount).put("date", i.date).put("monthYear", i.monthYear)
                        .put("isReceived", i.isReceived)
                        .put("receivedDate", i.receivedDate ?: JSONObject.NULL)
                        .put("studentId", i.studentId ?: JSONObject.NULL)
                        .put("paymentId", i.paymentId ?: JSONObject.NULL)
                        .put("notes", i.notes ?: JSONObject.NULL)
                )
            }
        })
        root.put("expenses", JSONArray().also { arr ->
            dao.getAllExpensesOnce().forEach { e ->
                arr.put(
                    JSONObject()
                        .put("id", e.id).put("title", e.title).put("amount", e.amount)
                        .put("category", e.category).put("date", e.date).put("monthYear", e.monthYear)
                        .put("notes", e.notes ?: JSONObject.NULL)
                )
            }
        })
        root.put("debts", JSONArray().also { arr ->
            dao.getAllDebtsOnce().forEach { d ->
                arr.put(
                    JSONObject()
                        .put("id", d.id).put("personName", d.personName)
                        .put("phoneNumber", d.phoneNumber ?: JSONObject.NULL)
                        .put("type", d.type).put("totalAmount", d.totalAmount)
                        .put("settledAmount", d.settledAmount).put("remainingAmount", d.remainingAmount)
                        .put("date", d.date).put("description", d.description)
                        .put("isFullySettled", d.isFullySettled)
                )
            }
        })
        root.put("settlements", JSONArray().also { arr ->
            dao.getAllSettlementsOnce().forEach { st ->
                arr.put(
                    JSONObject()
                        .put("id", st.id).put("debtId", st.debtId).put("amount", st.amount)
                        .put("date", st.date).put("note", st.note ?: JSONObject.NULL)
                )
            }
        })
        root.put("logs", JSONArray().also { arr ->
            dao.getAllLogsOnce().forEach { l ->
                arr.put(
                    JSONObject()
                        .put("id", l.id).put("action", l.action)
                        .put("details", l.details).put("timestamp", l.timestamp)
                )
            }
        })
        return root.toString(2)
    }

    private fun JSONObject.optStr(key: String): String? = if (isNull(key)) null else getString(key)

    private fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
        (0 until length()).map { transform(getJSONObject(it)) }

    /** ব্যাকআপ ফাইল থেকে সব তথ্য ফিরিয়ে আনে (বর্তমান তথ্য মুছে যায়)। */
    suspend fun importJson(text: String) {
        val root = JSONObject(text)
        require(root.optString("app") == "amar_hisab_khata") { "ভুল ব্যাকআপ ফাইল" }

        val students = root.getJSONArray("students").mapObjects { o ->
            StudentEntity(
                id = o.getString("id"), name = o.getString("name"),
                phoneNumber = o.getString("phoneNumber"), monthlyFee = o.getDouble("monthlyFee"),
                joiningDate = o.getString("joiningDate"), isActive = o.getBoolean("isActive"),
                notes = o.optStr("notes"), createdAt = o.getLong("createdAt")
            )
        }
        val fees = root.getJSONArray("fees").mapObjects { o ->
            MonthlyFeeEntity(
                id = o.getString("id"), studentId = o.getString("studentId"),
                monthYear = o.getString("monthYear"), amount = o.getDouble("amount"),
                paidAmount = o.getDouble("paidAmount"), dueAmount = o.getDouble("dueAmount"),
                status = o.getString("status"), lastPaymentDate = o.optStr("lastPaymentDate")
            )
        }
        val payments = root.getJSONArray("payments").mapObjects { o ->
            StudentPaymentEntity(
                id = o.getString("id"), studentId = o.getString("studentId"),
                feeId = o.getString("feeId"), amount = o.getDouble("amount"),
                paymentDate = o.getString("paymentDate"), monthYear = o.getString("monthYear"),
                receiptNumber = o.getString("receiptNumber"), notes = o.optStr("notes"),
                createdAt = o.getLong("createdAt")
            )
        }
        val incomes = root.getJSONArray("incomes").mapObjects { o ->
            IncomeEntity(
                id = o.getString("id"), category = o.getString("category"),
                title = o.getString("title"), amount = o.getDouble("amount"),
                date = o.getString("date"), monthYear = o.getString("monthYear"),
                isReceived = o.getBoolean("isReceived"), receivedDate = o.optStr("receivedDate"),
                studentId = o.optStr("studentId"), paymentId = o.optStr("paymentId"),
                notes = o.optStr("notes")
            )
        }
        val expenses = root.getJSONArray("expenses").mapObjects { o ->
            ExpenseEntity(
                id = o.getString("id"), title = o.getString("title"),
                amount = o.getDouble("amount"), category = o.getString("category"),
                date = o.getString("date"), monthYear = o.getString("monthYear"),
                notes = o.optStr("notes")
            )
        }
        val debts = root.getJSONArray("debts").mapObjects { o ->
            DebtEntity(
                id = o.getString("id"), personName = o.getString("personName"),
                phoneNumber = o.optStr("phoneNumber"), type = o.getString("type"),
                totalAmount = o.getDouble("totalAmount"), settledAmount = o.getDouble("settledAmount"),
                remainingAmount = o.getDouble("remainingAmount"), date = o.getString("date"),
                description = o.getString("description"), isFullySettled = o.getBoolean("isFullySettled")
            )
        }
        val settlements = (root.optJSONArray("settlements") ?: JSONArray()).mapObjects { o ->
            DebtSettlementEntity(
                id = o.getString("id"), debtId = o.getString("debtId"),
                amount = o.getDouble("amount"), date = o.getString("date"),
                note = o.optStr("note")
            )
        }
        val logs = root.getJSONArray("logs").mapObjects { o ->
            AuditLogEntity(
                id = o.getString("id"), action = o.getString("action"),
                details = o.getString("details"), timestamp = o.getLong("timestamp")
            )
        }

        db.withTransaction {
            dao.deleteAllPayments()
            dao.deleteAllFees()
            dao.deleteAllIncomes()
            dao.deleteAllExpenses()
            dao.deleteAllSettlements()
            dao.deleteAllDebts()
            dao.deleteAllStudents()
            dao.deleteAllLogs()

            students.forEach { dao.insertStudent(it) }
            if (fees.isNotEmpty()) dao.insertFees(fees)
            payments.forEach { dao.insertPayment(it) }
            incomes.forEach { dao.insertIncome(it) }
            expenses.forEach { dao.insertExpense(it) }
            debts.forEach { dao.insertDebt(it) }
            settlements.forEach { dao.insertSettlement(it) }
            logs.forEach { dao.insertLog(it) }
            log("ব্যাকআপ পুনরুদ্ধার", "ফাইল থেকে সব তথ্য ফিরিয়ে আনা হয়েছে")
        }
    }
}
