package com.amar.hisabkhata.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AppColorScheme = lightColorScheme(
    primary = PrimaryDarkGreen,
    onPrimary = Color.White,
    primaryContainer = LightGold,
    onPrimaryContainer = PrimaryDarkGreen,
    secondary = SecondaryGreen,
    onSecondary = Color.White,
    secondaryContainer = LightGold,
    onSecondaryContainer = PrimaryDarkGreen,
    tertiary = Purple,
    onTertiary = Color.White,
    tertiaryContainer = LightPurple,
    onTertiaryContainer = Purple,
    background = Background,
    onBackground = MainText,
    surface = CardBackground,
    onSurface = MainText,
    surfaceVariant = LightPurple,
    onSurfaceVariant = SecondaryText,
    error = ErrorRed,
    onError = Color.White
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun AmarHisabKhataTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        shapes = AppShapes,
        content = content
    )
}
