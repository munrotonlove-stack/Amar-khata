@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.data.local.entity.ExpenseEntity
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt
import com.amar.hisabkhata.util.Labels

@Composable
fun ExpenseScreen(vm: MainViewModel) {
    val month by vm.selectedMonth.collectAsState()
    val all by vm.expenses.collectAsState()

    var filter by remember { mutableStateOf("all") }
    var showAdd by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ExpenseEntity?>(null) }

    val today = Fmt.today()
    val monthItems = all.filter { it.monthYear == month }
    val rows = monthItems.filter { filter == "all" || it.category == filter }
    val monthTotal = monthItems.sumOf { it.amount }
    val todayTotal = all.filter { it.date == today }.sumOf { it.amount }

    ScreenWithFab(onFabClick = { showAdd = true }) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { MonthSwitcher(month, vm::setMonth) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryCard("আজকের খরচ", Fmt.money(todayTotal), WarningGold, Modifier.weight(1f))
                    SummaryCard("এ মাসের খরচ", Fmt.money(monthTotal), ErrorRed, Modifier.weight(1f))
                }
            }
            item {
                ChipRow(
                    options = listOf("all" to "সব") + Labels.expenseCategories,
                    selected = filter,
                    onSelect = { filter = it }
                )
            }
            if (rows.isEmpty()) {
                item { EmptyState("এই মাসে কোনো ব্যয়ের এন্ট্রি নেই") }
            }
            items(rows, key = { it.id }) { expense ->
                EntryCard(
                    title = expense.title,
                    subtitle = Labels.expense(expense.category) + " • " + Fmt.bn(expense.date),
                    amount = Fmt.money(expense.amount),
                    amountColor = ErrorRed,
                    actions = {
                        IconButton(onClick = { deleteTarget = expense }) {
                            Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = ErrorRed)
                        }
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddExpenseDialog(
            onDismiss = { showAdd = false },
            onSave = {
                vm.addExpense(it)
                showAdd = false
            }
        )
    }

    deleteTarget?.let { expense ->
        DeleteConfirmDialog(
            message = "\"${expense.title}\" (${Fmt.money(expense.amount)}) মুছে ফেলবেন?",
            onConfirm = {
                vm.deleteExpense(expense)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun AddExpenseDialog(onDismiss: () -> Unit, onSave: (ExpenseEntity) -> Unit) {
    var category by remember { mutableStateOf(Labels.expenseCategories.first().first) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var notes by remember { mutableStateOf("") }

    val value = Fmt.parseAmount(amount)

    FormDialog(
        title = "নতুন ব্যয়",
        onDismiss = onDismiss,
        confirmEnabled = value != null && value > 0.0 && Fmt.isValidDate(date),
        onConfirm = {
            onSave(
                ExpenseEntity(
                    id = Fmt.newId(),
                    title = title.ifBlank { Labels.expense(category) },
                    amount = value ?: 0.0,
                    category = category,
                    date = date,
                    monthYear = date.take(7),
                    notes = notes.ifBlank { null }
                )
            )
        }
    ) {
        Text("খাত", style = MaterialTheme.typography.labelMedium)
        ChipRow(Labels.expenseCategories, category) { category = it }
        AppTextField(title, { title = it }, "বিবরণ (ঐচ্ছিক)")
        AppTextField(amount, { amount = it }, "পরিমাণ (৳)", keyboardType = KeyboardType.Decimal)
        DateField(date, { date = it })
        AppTextField(notes, { notes = it }, "নোট (ঐচ্ছিক)", singleLine = false)
    }
}
