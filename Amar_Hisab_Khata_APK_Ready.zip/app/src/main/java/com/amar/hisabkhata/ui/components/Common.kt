@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt
import kotlin.math.max

@Composable
fun MonthSwitcher(month: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = { onChange(Fmt.shiftMonth(month, -1)) }) {
            Icon(Icons.Filled.ChevronLeft, contentDescription = "আগের মাস")
        }
        Text(
            Fmt.monthLabel(month),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = PrimaryDarkGreen
        )
        IconButton(onClick = { onChange(Fmt.shiftMonth(month, 1)) }) {
            Icon(Icons.Filled.ChevronRight, contentDescription = "পরের মাস")
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier
                    .size(width = 28.dp, height = 4.dp)
                    .background(accent, RoundedCornerShape(2.dp))
            )
            Spacer(Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.bodySmall, color = SecondaryText)
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = PrimaryDarkGreen
    )
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = SecondaryText, textAlign = TextAlign.Center)
    }
}

@Composable
fun StatusBadge(status: String) {
    val (label, color) = when (status) {
        "paid" -> "পরিশোধিত" to SuccessGreen
        "partial" -> "আংশিক" to WarningGold
        else -> "বকেয়া" to ErrorRed
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50)) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            color = color,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun ChipRow(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (key, label) ->
            FilterChip(
                selected = key == selected,
                onClick = { onSelect(key) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
fun AppTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    isError: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine,
        isError = isError,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType)
    )
}

@Composable
fun DateField(value: String, onChange: (String) -> Unit, label: String = "তারিখ (YYYY-MM-DD)") {
    AppTextField(
        value = value,
        onValueChange = onChange,
        label = label,
        isError = value.isNotEmpty() && !Fmt.isValidDate(value)
    )
}

@Composable
fun FormDialog(
    title: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmText: String = "সংরক্ষণ",
    confirmEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        },
        confirmButton = {
            Button(onClick = onConfirm, enabled = confirmEnabled) { Text(confirmText) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}

@Composable
fun ScreenWithFab(
    onFabClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier.fillMaxSize()) {
        content()
        FloatingActionButton(
            onClick = onFabClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = Gold,
            contentColor = PrimaryDarkGreen
        ) {
            Icon(Icons.Filled.Add, contentDescription = "যোগ করুন")
        }
    }
}

@Composable
fun EntryCard(
    title: String,
    subtitle: String,
    amount: String,
    amountColor: Color,
    modifier: Modifier = Modifier,
    badge: String? = null,
    badgeColor: Color = SecondaryText,
    actions: (@Composable RowScope.() -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold, color = MainText)
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(amount, fontWeight = FontWeight.Bold, color = amountColor)
                    if (badge != null) {
                        Text(badge, style = MaterialTheme.typography.labelSmall, color = badgeColor)
                    }
                }
            }
            if (actions != null) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                    content = actions
                )
            }
        }
    }
}

/** আয় বনাম ব্যয়ের জোড়া বার চার্ট */
@Composable
fun MonthlyBarChart(
    months: List<String>,
    income: List<Double>,
    expense: List<Double>,
    modifier: Modifier = Modifier
) {
    val maxValue = max(1.0, (income + expense).maxOrNull() ?: 1.0)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            val groupWidth = size.width / months.size
            val barWidth = groupWidth * 0.28f
            months.indices.forEach { i ->
                val center = i * groupWidth + groupWidth / 2f
                val incomeHeight = (income[i] / maxValue).toFloat() * size.height
                val expenseHeight = (expense[i] / maxValue).toFloat() * size.height
                drawRect(
                    color = SuccessGreen,
                    topLeft = Offset(center - barWidth - 2f, size.height - incomeHeight),
                    size = Size(barWidth, incomeHeight)
                )
                drawRect(
                    color = ErrorRed,
                    topLeft = Offset(center + 2f, size.height - expenseHeight),
                    size = Size(barWidth, expenseHeight)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth()) {
            months.forEach {
                Text(
                    Fmt.shortMonth(it),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontSize = 11.sp,
                    color = SecondaryText
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            LegendDot(SuccessGreen, "আয়")
            LegendDot(ErrorRed, "ব্যয়")
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .background(color, RoundedCornerShape(50))
        )
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp, color = SecondaryText)
    }
}
