@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.data.local.entity.DebtEntity
import com.amar.hisabkhata.data.local.entity.DebtSettlementEntity
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt

@Composable
fun DebtReceivableScreen(vm: MainViewModel) {
    val debts by vm.debts.collectAsState()
    val settlements by vm.settlements.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var settleTarget by remember { mutableStateOf<DebtEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<DebtEntity?>(null) }
    var cancelTarget by remember { mutableStateOf<DebtSettlementEntity?>(null) }

    val type = if (tab == 0) "owe_others" else "others_owe_me"
    val rows = debts.filter { it.type == type }
    val remainingTotal = rows.sumOf { it.remainingAmount }
    val accent = if (tab == 0) WarningGold else Purple

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = CardBackground) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("দেনা (আমি দেব)") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("পাওনা (আমি পাব)") })
        }

        ScreenWithFab(onFabClick = { showAdd = true }, modifier = Modifier.weight(1f)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    SummaryCard(
                        title = if (tab == 0) "মোট বাকি দেনা" else "মোট বাকি পাওনা",
                        value = Fmt.money(remainingTotal),
                        accent = accent,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (rows.isEmpty()) {
                    item { EmptyState(if (tab == 0) "কোনো দেনা নেই" else "কোনো পাওনা নেই") }
                }
                items(rows, key = { it.id }) { debt ->
                    DebtCard(
                        debt = debt,
                        history = settlements.filter { it.debtId == debt.id },
                        accent = accent,
                        onCancelSettlement = { cancelTarget = it },
                        onSettle = { settleTarget = debt },
                        onDelete = { deleteTarget = debt }
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddDebtDialog(
            type = type,
            onDismiss = { showAdd = false },
            onSave = {
                vm.addDebt(it)
                showAdd = false
            }
        )
    }

    settleTarget?.let { debt ->
        SettleDialog(
            debt = debt,
            onDismiss = { settleTarget = null },
            onSettle = { amount, date ->
                vm.settleDebt(debt, amount, date)
                settleTarget = null
            }
        )
    }

    cancelTarget?.let { st ->
        DeleteConfirmDialog(
            title = "নিষ্পত্তি বাতিল করবেন?",
            message = "${Fmt.money(st.amount)} এর নিষ্পত্তি বাতিল হলে বাকি পরিমাণ আবার বেড়ে যাবে।",
            onConfirm = {
                vm.deleteSettlement(st)
                cancelTarget = null
            },
            onDismiss = { cancelTarget = null }
        )
    }

    deleteTarget?.let { debt ->
        DeleteConfirmDialog(
            message = "\"${debt.personName}\" এর হিসাবটি মুছে ফেলবেন?",
            onConfirm = {
                vm.deleteDebt(debt)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun DebtCard(
    debt: DebtEntity,
    history: List<DebtSettlementEntity>,
    accent: androidx.compose.ui.graphics.Color,
    onCancelSettlement: (DebtSettlementEntity) -> Unit,
    onSettle: () -> Unit,
    onDelete: () -> Unit
) {
    var showHistory by remember { mutableStateOf(false) }
    val progress = if (debt.totalAmount > 0.0) (debt.settledAmount / debt.totalAmount).toFloat() else 0f

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(debt.personName, fontWeight = FontWeight.SemiBold, color = MainText)
                    Text(
                        debt.description + " • " + Fmt.bn(debt.date),
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
                if (debt.isFullySettled) {
                    Text("নিষ্পত্তি হয়েছে", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                } else {
                    Text(Fmt.money(debt.remainingAmount), color = accent, fontWeight = FontWeight.Bold)
                }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth(),
                color = SuccessGreen,
                trackColor = LightGold
            )
            Text(
                "মোট ${Fmt.money(debt.totalAmount)} • নিষ্পত্তি ${Fmt.money(debt.settledAmount)}",
                style = MaterialTheme.typography.bodySmall,
                color = SecondaryText
            )
            if (showHistory) {
                history.forEach { st ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            Fmt.bn(st.date) + " — " + Fmt.money(st.amount),
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            color = MainText
                        )
                        TextButton(onClick = { onCancelSettlement(st) }) {
                            Text("বাতিল", color = ErrorRed)
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (history.isNotEmpty()) {
                    TextButton(onClick = { showHistory = !showHistory }) {
                        Text(if (showHistory) "ইতিহাস লুকান" else "নিষ্পত্তির ইতিহাস (${Fmt.bn(history.size.toString())})")
                    }
                }
                if (!debt.isFullySettled) {
                    Button(onClick = onSettle, contentPadding = PaddingValues(horizontal = 14.dp)) {
                        Text("নিষ্পত্তি")
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = ErrorRed)
                }
            }
        }
    }
}

@Composable
private fun AddDebtDialog(type: String, onDismiss: () -> Unit, onSave: (DebtEntity) -> Unit) {
    var person by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var description by remember { mutableStateOf("") }

    val value = Fmt.parseAmount(amount)

    FormDialog(
        title = if (type == "owe_others") "নতুন দেনা" else "নতুন পাওনা",
        onDismiss = onDismiss,
        confirmEnabled = person.isNotBlank() && value != null && value > 0.0 && Fmt.isValidDate(date),
        onConfirm = {
            onSave(
                DebtEntity(
                    id = Fmt.newId(),
                    personName = person.trim(),
                    phoneNumber = phone.ifBlank { null },
                    type = type,
                    totalAmount = value ?: 0.0,
                    settledAmount = 0.0,
                    remainingAmount = value ?: 0.0,
                    date = date,
                    description = description.ifBlank { "বিবরণ নেই" }
                )
            )
        }
    ) {
        AppTextField(person, { person = it }, "ব্যক্তির নাম")
        AppTextField(phone, { phone = it }, "ফোন নম্বর (ঐচ্ছিক)", keyboardType = KeyboardType.Phone)
        AppTextField(amount, { amount = it }, "পরিমাণ (৳)", keyboardType = KeyboardType.Decimal)
        DateField(date, { date = it })
        AppTextField(description, { description = it }, "বিবরণ", singleLine = false)
    }
}

@Composable
private fun SettleDialog(debt: DebtEntity, onDismiss: () -> Unit, onSettle: (Double, String) -> Unit) {
    var amount by remember { mutableStateOf(Fmt.plain(debt.remainingAmount)) }
    var date by remember { mutableStateOf(Fmt.today()) }
    val value = Fmt.parseAmount(amount)

    FormDialog(
        title = "নিষ্পত্তি: ${debt.personName}",
        confirmText = "নিষ্পত্তি করুন",
        onDismiss = onDismiss,
        confirmEnabled = value != null && value > 0.0 && Fmt.isValidDate(date),
        onConfirm = { onSettle(value ?: 0.0, date) }
    ) {
        Text(
            "বাকি আছে ${Fmt.money(debt.remainingAmount)}। আংশিক বা পুরো পরিমাণ লিখুন।",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryText
        )
        AppTextField(amount, { amount = it }, "নিষ্পত্তির পরিমাণ (৳)", keyboardType = KeyboardType.Decimal)
        DateField(date, { date = it })
    }
}
