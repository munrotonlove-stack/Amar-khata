@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.data.local.entity.IncomeEntity
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.*
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.Fmt
import com.amar.hisabkhata.util.Labels

@Composable
fun IncomeScreen(vm: MainViewModel) {
    val month by vm.selectedMonth.collectAsState()
    val all by vm.incomes.collectAsState()

    var filter by remember { mutableStateOf("all") }
    var showAdd by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<IncomeEntity?>(null) }

    val rows = all.filter { it.monthYear == month && (filter == "all" || it.category == filter) }
    val received = rows.filter { it.isReceived }.sumOf { it.amount }
    val pending = rows.filter { !it.isReceived }.sumOf { it.amount }

    ScreenWithFab(onFabClick = { showAdd = true }) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { MonthSwitcher(month, vm::setMonth) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryCard("প্রাপ্ত আয়", Fmt.money(received), SuccessGreen, Modifier.weight(1f))
                    SummaryCard("অপেক্ষমাণ", Fmt.money(pending), WarningGold, Modifier.weight(1f))
                }
            }
            item {
                ChipRow(
                    options = listOf("all" to "সব") + Labels.incomeCategories,
                    selected = filter,
                    onSelect = { filter = it }
                )
            }
            if (rows.isEmpty()) {
                item { EmptyState("এই মাসে কোনো আয়ের এন্ট্রি নেই") }
            }
            items(rows, key = { it.id }) { income ->
                EntryCard(
                    title = income.title,
                    subtitle = Labels.income(income.category) + " • " + Fmt.bn(income.date),
                    amount = Fmt.money(income.amount),
                    amountColor = if (income.isReceived) SuccessGreen else WarningGold,
                    badge = if (income.isReceived) null else "অপেক্ষমাণ",
                    badgeColor = WarningGold,
                    actions = {
                        if (!income.isReceived) {
                            TextButton(onClick = { vm.markReceived(income) }) { Text("প্রাপ্ত হয়েছে") }
                        }
                        IconButton(onClick = { deleteTarget = income }) {
                            Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = ErrorRed)
                        }
                    }
                )
            }
        }
    }

    if (showAdd) {
        AddIncomeDialog(
            onDismiss = { showAdd = false },
            onSave = {
                vm.addIncome(it)
                showAdd = false
            }
        )
    }

    deleteTarget?.let { income ->
        DeleteConfirmDialog(
            message = if (income.paymentId != null)
                "এটি ছাত্র বেতনের আয়। মুছলে শিক্ষার্থীর ওই মাসের ফি আবার বকেয়া হয়ে যাবে।"
            else "\"${income.title}\" এন্ট্রিটি মুছে ফেলবেন?",
            onConfirm = {
                vm.deleteIncome(income)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun AddIncomeDialog(onDismiss: () -> Unit, onSave: (IncomeEntity) -> Unit) {
    val categories = Labels.incomeCategories.filter { it.first != "student_fee" }
    var category by remember { mutableStateOf(categories.first().first) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var received by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    val value = Fmt.parseAmount(amount)

    FormDialog(
        title = "নতুন আয়",
        onDismiss = onDismiss,
        confirmEnabled = value != null && value > 0.0 && Fmt.isValidDate(date),
        onConfirm = {
            onSave(
                IncomeEntity(
                    id = Fmt.newId(),
                    category = category,
                    title = title.ifBlank { Labels.income(category) },
                    amount = value ?: 0.0,
                    date = date,
                    monthYear = date.take(7),
                    isReceived = received,
                    receivedDate = if (received) date else null,
                    notes = notes.ifBlank { null }
                )
            )
        }
    ) {
        Text("খাত", style = MaterialTheme.typography.labelMedium)
        ChipRow(categories, category) { category = it }
        AppTextField(title, { title = it }, "বিবরণ (ঐচ্ছিক)")
        AppTextField(amount, { amount = it }, "পরিমাণ (৳)", keyboardType = KeyboardType.Decimal)
        DateField(date, { date = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("টাকা হাতে পেয়েছি", Modifier.weight(1f))
            Switch(checked = received, onCheckedChange = { received = it })
        }
        AppTextField(notes, { notes = it }, "নোট (ঐচ্ছিক)", singleLine = false)
    }
}
