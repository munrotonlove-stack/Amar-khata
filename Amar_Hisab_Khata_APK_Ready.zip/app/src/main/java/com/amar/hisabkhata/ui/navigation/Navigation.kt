@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.screens.*
import com.amar.hisabkhata.ui.theme.Gold
import com.amar.hisabkhata.ui.theme.PrimaryDarkGreen

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    NavItem("home", "হোম", Icons.Filled.Home),
    NavItem("students", "শিক্ষার্থী", Icons.Filled.School),
    NavItem("income", "আয়", Icons.Filled.AccountBalanceWallet),
    NavItem("expense", "ব্যয়", Icons.Filled.ShoppingCart),
    NavItem("debts", "দেনা-পাওনা", Icons.Filled.SwapHoriz)
)

private fun titleFor(route: String): String = when (route) {
    "home" -> "আমার হিসাব খাতা"
    "students" -> "শিক্ষার্থী ও ফি"
    "income" -> "আয়"
    "expense" -> "ব্যয়"
    "debts" -> "দেনা ও পাওনা"
    "reports" -> "রিপোর্ট"
    "settings" -> "সেটিংস"
    else -> "আমার হিসাব খাতা"
}

@Composable
fun MainAppNavigation(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route ?: "home"
    val isMain = bottomItems.any { it.route == route }

    fun goMain(target: String) {
        nav.navigate(target) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(titleFor(route), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (!isMain) {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পিছনে")
                        }
                    }
                },
                actions = {
                    if (isMain) {
                        IconButton(onClick = { nav.navigate("reports") { launchSingleTop = true } }) {
                            Icon(Icons.Filled.Assessment, contentDescription = "রিপোর্ট")
                        }
                        IconButton(onClick = { nav.navigate("settings") { launchSingleTop = true } }) {
                            Icon(Icons.Filled.Settings, contentDescription = "সেটিংস")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryDarkGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Gold
                )
            )
        },
        bottomBar = {
            if (isMain) {
                NavigationBar(containerColor = Color.White) {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = route == item.route,
                            onClick = { goMain(item.route) },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 11.sp, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(vm, onNavigate = { goMain(it) }) }
            composable("students") { StudentsScreen(vm) }
            composable("income") { IncomeScreen(vm) }
            composable("expense") { ExpenseScreen(vm) }
            composable("debts") { DebtReceivableScreen(vm) }
            composable("reports") { ReportsScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
        }
    }
}
