@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.hisabkhata.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.amar.hisabkhata.ui.MainViewModel
import com.amar.hisabkhata.ui.components.DeleteConfirmDialog
import com.amar.hisabkhata.ui.components.FormDialog
import com.amar.hisabkhata.ui.components.SectionTitle
import com.amar.hisabkhata.ui.theme.*
import com.amar.hisabkhata.util.PinStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var hasPin by remember { mutableStateOf(PinStore.hasPin(context)) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showRemovePin by remember { mutableStateOf(false) }
    var pendingRestoreText by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = try {
                    val json = vm.exportJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
                Toast.makeText(
                    context,
                    if (ok) "ব্যাকআপ সংরক্ষণ হয়েছে" else "ব্যাকআপ সংরক্ষণ ব্যর্থ হয়েছে",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val text = try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    }
                } catch (e: Exception) {
                    null
                }
                if (text == null) {
                    Toast.makeText(context, "ফাইলটি পড়া যায়নি", Toast.LENGTH_LONG).show()
                } else {
                    pendingRestoreText = text
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCard("নিরাপত্তা") {
            Text(
                if (hasPin) "অ্যাপ খুলতে ৪ সংখ্যার পিন লাগবে।" else "পিন চালু করলে অ্যাপ খুলতে পিন দিতে হবে।",
                color = SecondaryText
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showPinDialog = true }) {
                    Text(if (hasPin) "পিন পরিবর্তন" else "পিন চালু করুন")
                }
                if (hasPin) {
                    OutlinedButton(onClick = { showRemovePin = true }) { Text("পিন বন্ধ করুন") }
                }
            }
        }

        SettingsCard("ব্যাকআপ ও পুনরুদ্ধার") {
            Text(
                "সব তথ্য একটি ফাইলে সংরক্ষণ করে রাখুন। ফোন বদলালে বা অ্যাপ মুছলে ওই ফাইল থেকে ফিরিয়ে আনতে পারবেন।",
                color = SecondaryText
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportLauncher.launch("amar_hisab_khata_backup.json") }) {
                    Text("ব্যাকআপ নিন")
                }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                    Text("ব্যাকআপ থেকে ফিরান")
                }
            }
        }

        SettingsCard("অ্যাপ সম্পর্কে") {
            Text("আমার হিসাব খাতা", fontWeight = FontWeight.Bold, color = MainText)
            Text("সংস্করণ ১.০.০", color = SecondaryText)
            Text(
                "সম্পূর্ণ অফলাইন অ্যাপ। আপনার সব তথ্য শুধু আপনার ফোনেই থাকে, কোথাও পাঠানো হয় না।",
                color = SecondaryText
            )
        }
    }

    if (showPinDialog) {
        SetPinDialog(
            onDismiss = { showPinDialog = false },
            onSet = {
                PinStore.setPin(context, it)
                hasPin = true
                showPinDialog = false
                Toast.makeText(context, "পিন সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showRemovePin) {
        DeleteConfirmDialog(
            title = "পিন বন্ধ করবেন?",
            message = "পিন বন্ধ করলে যে কেউ অ্যাপ খুলে হিসাব দেখতে পারবে।",
            onConfirm = {
                PinStore.clearPin(context)
                hasPin = false
                showRemovePin = false
            },
            onDismiss = { showRemovePin = false }
        )
    }

    pendingRestoreText?.let { text ->
        DeleteConfirmDialog(
            title = "ব্যাকআপ থেকে ফিরাবেন?",
            message = "বর্তমান সব তথ্য মুছে গিয়ে ব্যাকআপ ফাইলের তথ্য বসবে। এটি আর ফেরানো যাবে না।",
            onConfirm = {
                pendingRestoreText = null
                scope.launch {
                    val ok = vm.importJson(text)
                    Toast.makeText(
                        context,
                        if (ok) "তথ্য ফিরিয়ে আনা হয়েছে" else "ফাইলটি সঠিক ব্যাকআপ নয়",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            onDismiss = { pendingRestoreText = null }
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = {
                SectionTitle(title)
                content()
            }
        )
    }
}

@Composable
private fun SetPinDialog(onDismiss: () -> Unit, onSet: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val valid = pin.length == 4 && pin == confirm

    FormDialog(
        title = "৪ সংখ্যার পিন দিন",
        onDismiss = onDismiss,
        confirmEnabled = valid,
        onConfirm = { onSet(pin) }
    ) {
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it },
            label = { Text("নতুন পিন") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = confirm,
            onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirm = it },
            label = { Text("পিন আবার লিখুন") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            isError = confirm.length == 4 && pin != confirm,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** অ্যাপ খোলার সময় দেখানো পিন লক স্ক্রিন */
@Composable
fun PinLockScreen(onUnlocked: () -> Unit) {
    val context = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Filled.Lock,
            contentDescription = null,
            tint = PrimaryDarkGreen,
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "আমার হিসাব খাতা",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = PrimaryDarkGreen
        )
        Spacer(Modifier.height(4.dp))
        Text("চালিয়ে যেতে আপনার পিন দিন", color = SecondaryText, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all { c -> c.isDigit() }) {
                    pin = it
                    error = false
                    if (it.length == 4) {
                        if (PinStore.verify(context, it)) {
                            onUnlocked()
                        } else {
                            error = true
                            pin = ""
                        }
                    }
                }
            },
            label = { Text("পিন") },
            singleLine = true,
            isError = error,
            supportingText = { if (error) Text("পিন ভুল হয়েছে, আবার চেষ্টা করুন") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        )
    }
}
