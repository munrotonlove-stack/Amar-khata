package com.amar.hisabkhata.util

import android.content.Context
import java.security.MessageDigest

object PinStore {
    private const val FILE = "amar_prefs"
    private const val KEY = "pin_hash"

    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(("amar_hisab_$pin").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(c: Context): Boolean = prefs(c).contains(KEY)
    fun setPin(c: Context, pin: String) = prefs(c).edit().putString(KEY, hash(pin)).apply()
    fun clearPin(c: Context) = prefs(c).edit().remove(KEY).apply()
    fun verify(c: Context, pin: String): Boolean = prefs(c).getString(KEY, null) == hash(pin)
}
