package com.amar.hisabkhata.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object Fmt {
    private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    private val monthNames = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    fun newId(): String = UUID.randomUUID().toString()

    /** ইংরেজি অঙ্ক → বাংলা অঙ্ক */
    fun bn(s: String): String = buildString {
        s.forEach { c -> append(if (c in '0'..'9') bnDigits[c - '0'] else c) }
    }

    /** বাংলা/ইংরেজি অঙ্ক থেকে সংখ্যা পার্স */
    fun parseAmount(s: String): Double? {
        val latin = buildString {
            s.trim().forEach { c ->
                val idx = bnDigits.indexOf(c)
                append(if (idx >= 0) '0' + idx else c)
            }
        }
        return latin.replace(",", "").toDoubleOrNull()
    }

    fun plain(v: Double): String =
        if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

    fun money(v: Double): String {
        val txt = if (v % 1.0 == 0.0) String.format(Locale.US, "%,.0f", v)
        else String.format(Locale.US, "%,.2f", v)
        return "৳ " + bn(txt)
    }

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun currentMonth(): String = today().take(7)

    fun dateTime(ts: Long): String =
        bn(SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US).format(Date(ts)))

    fun shiftMonth(m: String, delta: Int): String {
        val y = m.substring(0, 4).toInt()
        val mo = m.substring(5, 7).toInt() - 1
        val total = y * 12 + mo + delta
        return String.format(Locale.US, "%04d-%02d", total / 12, total % 12 + 1)
    }

    fun monthName(monthNumber: Int): String = monthNames[monthNumber - 1]

    fun monthLabel(m: String): String =
        monthNames[m.substring(5, 7).toInt() - 1] + " " + bn(m.substring(0, 4))

    fun shortMonth(m: String): String = bn(m.substring(5, 7))

    fun isValidDate(s: String): Boolean {
        if (!Regex("\\d{4}-\\d{2}-\\d{2}").matches(s)) return false
        val mo = s.substring(5, 7).toInt()
        val d = s.substring(8, 10).toInt()
        return mo in 1..12 && d in 1..31
    }
}

object Labels {
    val incomeCategories = listOf(
        "student_fee" to "ছাত্র বেতন",
        "madrasa_salary" to "মাদ্রাসা বেতন",
        "mosque_salary" to "মসজিদ বেতন",
        "other_income" to "অন্যান্য আয়"
    )
    val expenseCategories = listOf(
        "bazar" to "বাজার",
        "house_rent" to "বাসা ভাড়া",
        "medical" to "চিকিৎসা",
        "utility" to "বিল/ইউটিলিটি",
        "transport" to "যাতায়াত",
        "education" to "শিক্ষা",
        "other" to "অন্যান্য"
    )

    fun income(key: String): String = incomeCategories.firstOrNull { it.first == key }?.second ?: key
    fun expense(key: String): String = expenseCategories.firstOrNull { it.first == key }?.second ?: key
}
