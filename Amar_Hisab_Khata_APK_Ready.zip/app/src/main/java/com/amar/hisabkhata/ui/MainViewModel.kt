package com.amar.hisabkhata.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.amar.hisabkhata.AmarHisabKhataApp
import com.amar.hisabkhata.data.local.entity.*
import com.amar.hisabkhata.util.Fmt
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as AmarHisabKhataApp).repository

    val selectedMonth = MutableStateFlow(Fmt.currentMonth())

    val students: StateFlow<List<StudentEntity>> =
        repo.students.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val incomes: StateFlow<List<IncomeEntity>> =
        repo.incomes.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val expenses: StateFlow<List<ExpenseEntity>> =
        repo.expenses.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debts: StateFlow<List<DebtEntity>> =
        repo.debts.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settlements: StateFlow<List<DebtSettlementEntity>> =
        repo.settlements.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val logs: StateFlow<List<AuditLogEntity>> =
        repo.logs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val monthFees: StateFlow<List<MonthlyFeeEntity>> =
        selectedMonth
            .flatMapLatest { repo.feesForMonth(it) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // মাস বদলালে বা নতুন শিক্ষার্থী যোগ হলে ওই মাসের ফি এন্ট্রি তৈরি হবে
        viewModelScope.launch {
            combine(repo.students, selectedMonth) { _, month -> month }
                .collect { repo.generateFees(it) }
        }
    }

    fun setMonth(month: String) {
        selectedMonth.value = month
    }

    // ---- Students ----
    fun saveStudent(student: StudentEntity, isNew: Boolean) =
        viewModelScope.launch { repo.saveStudent(student, isNew) }

    fun deleteStudent(student: StudentEntity) =
        viewModelScope.launch { repo.deleteStudent(student) }

    fun payFee(student: StudentEntity, fee: MonthlyFeeEntity, amount: Double, date: String) =
        viewModelScope.launch { repo.payFee(student, fee, amount, date) }

    // ---- Income ----
    fun addIncome(income: IncomeEntity) = viewModelScope.launch { repo.addIncome(income) }
    fun markReceived(income: IncomeEntity) =
        viewModelScope.launch { repo.markIncomeReceived(income, Fmt.today()) }
    fun deleteIncome(income: IncomeEntity) = viewModelScope.launch { repo.deleteIncome(income) }

    // ---- Expense ----
    fun addExpense(expense: ExpenseEntity) = viewModelScope.launch { repo.addExpense(expense) }
    fun deleteExpense(expense: ExpenseEntity) = viewModelScope.launch { repo.deleteExpense(expense) }

    // ---- Debts ----
    fun addDebt(debt: DebtEntity) = viewModelScope.launch { repo.addDebt(debt) }
    fun settleDebt(debt: DebtEntity, amount: Double, date: String) =
        viewModelScope.launch { repo.settleDebt(debt, amount, date) }
    fun deleteSettlement(settlement: DebtSettlementEntity) =
        viewModelScope.launch { repo.deleteSettlement(settlement) }
    fun deleteDebt(debt: DebtEntity) = viewModelScope.launch { repo.deleteDebt(debt) }

    // ---- Backup ----
    suspend fun exportJson(): String = repo.exportJson()

    suspend fun importJson(text: String): Boolean =
        try {
            repo.importJson(text)
            true
        } catch (e: Exception) {
            false
        }
}
