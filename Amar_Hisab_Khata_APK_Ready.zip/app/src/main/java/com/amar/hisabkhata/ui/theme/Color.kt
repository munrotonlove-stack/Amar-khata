package com.amar.hisabkhata.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryDarkGreen = Color(0xFF123B2A)
val SecondaryGreen = Color(0xFF1F6B4A)
val Gold = Color(0xFFD4AF37)
val LightGold = Color(0xFFF4E6B0)
val Purple = Color(0xFF7356A8)
val LightPurple = Color(0xFFF0EAF8)
val Background = Color(0xFFF7F8F5)
val CardBackground = Color(0xFFFFFFFF)
val MainText = Color(0xFF202820)
val SecondaryText = Color(0xFF68736B)
val SuccessGreen = Color(0xFF218653)
val WarningGold = Color(0xFFD99A25)
val ErrorRed = Color(0xFFC74747)
